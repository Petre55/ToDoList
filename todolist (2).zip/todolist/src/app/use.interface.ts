export interface UserInterface{
    email:string;
    displayName :string;
}