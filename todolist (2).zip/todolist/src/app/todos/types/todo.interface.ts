export interface TodoInterface {
    id: string;
    email:string;
    text: string;
    isCompleted: boolean;
  }