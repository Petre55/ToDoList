export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyBSGNw-EYBW2M5UjkKDd5AHpfQ2oWvlIlg",
    authDomain: "keller05.firebaseapp.com",
    projectId: "keller05",
    storageBucket: "keller05.firebasestorage.app",
    messagingSenderId: "452921123770",
    appId: "1:452921123770:web:8cd653619e0ecc3482b383"
  }
};
